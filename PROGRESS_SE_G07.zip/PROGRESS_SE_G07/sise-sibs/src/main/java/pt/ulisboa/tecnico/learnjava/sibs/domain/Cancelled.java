package pt.ulisboa.tecnico.learnjava.sibs.domain;

public class Cancelled extends state {
}
