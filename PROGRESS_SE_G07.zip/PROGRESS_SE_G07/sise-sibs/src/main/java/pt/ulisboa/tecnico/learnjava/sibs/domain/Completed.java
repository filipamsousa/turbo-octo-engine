package pt.ulisboa.tecnico.learnjava.sibs.domain;

public class Completed extends state {
}
