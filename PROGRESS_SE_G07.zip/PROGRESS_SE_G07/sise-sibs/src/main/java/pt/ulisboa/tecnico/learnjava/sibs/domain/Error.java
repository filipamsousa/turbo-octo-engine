package pt.ulisboa.tecnico.learnjava.sibs.domain;

public class Error extends state {

}
