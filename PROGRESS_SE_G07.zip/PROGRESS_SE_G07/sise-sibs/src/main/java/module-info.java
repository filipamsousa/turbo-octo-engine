module pt.ulisboa.tecnico.learnjava.sibs {
	requires pt.ulisboa.tecnico.learnjava.bank;
}