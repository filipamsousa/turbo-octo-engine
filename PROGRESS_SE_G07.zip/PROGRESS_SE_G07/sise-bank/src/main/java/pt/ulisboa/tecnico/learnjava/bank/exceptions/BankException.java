package pt.ulisboa.tecnico.learnjava.bank.exceptions;

public class BankException extends Exception {

}
