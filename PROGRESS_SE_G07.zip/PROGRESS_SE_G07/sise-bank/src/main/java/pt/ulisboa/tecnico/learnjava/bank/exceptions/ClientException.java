package pt.ulisboa.tecnico.learnjava.bank.exceptions;

public class ClientException extends Exception {

}
